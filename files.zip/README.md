# 🤖 LM Studio API Wrapper

A Node.js/Express API that wraps your local LM Studio server with conversation history, sessions, personas, and multiple endpoints.

## Prerequisites
- LM Studio running with a model loaded
- Local server started at `http://127.0.0.1:1234`
- Node.js 18+

## Setup

```bash
npm install
npm start        # production
npm run dev      # auto-restart on file changes
```

Server runs at: `http://localhost:3000`

---

## API Endpoints

### GET `/health`
Check if your server and LM Studio are connected.
```bash
curl http://localhost:3000/health
```
**Response:**
```json
{ "status": "ok", "lmStudio": "connected", "loadedModels": ["google/gemma-3-4b"] }
```

---

### POST `/chat`
Simple one-shot message. No history saved.
```bash
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{ "message": "What is 2+2?", "systemPrompt": "You are a math tutor." }'
```
**Body:**
| Field | Required | Description |
|---|---|---|
| `message` | ✅ | Your message |
| `systemPrompt` | ❌ | Custom AI personality |

---

### POST `/session/start`
Start a new conversation session with memory.
```bash
curl -X POST http://localhost:3000/session/start \
  -H "Content-Type: application/json" \
  -d '{ "systemPrompt": "You are a helpful customer support agent." }'
```
**Response:** `{ "sessionId": "abc-123", "message": "Session started." }`

---

### POST `/session/:sessionId/message`
Send a message in an existing session (remembers history).
```bash
curl -X POST http://localhost:3000/session/abc-123/message \
  -H "Content-Type: application/json" \
  -d '{ "message": "What did I just ask you?" }'
```

---

### GET `/session/:sessionId/history`
Get the full conversation history of a session.
```bash
curl http://localhost:3000/session/abc-123/history
```

---

### DELETE `/session/:sessionId`
Clear and delete a session.
```bash
curl -X DELETE http://localhost:3000/session/abc-123
```

---

### POST `/personas`
Chat with a preset AI personality.

**Available personas:** `assistant`, `coder`, `teacher`, `writer`

```bash
curl -X POST http://localhost:3000/personas \
  -H "Content-Type: application/json" \
  -d '{ "persona": "coder", "message": "Write a Node.js hello world" }'
```

**Body:**
| Field | Required | Description |
|---|---|---|
| `persona` | ✅ | One of the preset personas |
| `message` | ✅ | Your message |
| `sessionId` | ❌ | Continue an existing session |

---

## JavaScript Usage Example

```javascript
// Start a session
const { sessionId } = await fetch("http://localhost:3000/session/start", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ systemPrompt: "You are a helpful assistant." })
}).then(r => r.json());

// Chat with memory
const { reply } = await fetch(`http://localhost:3000/session/${sessionId}/message`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ message: "Hello!" })
}).then(r => r.json());

console.log(reply);
```

---

## Config (server.js)

```js
const LM_STUDIO_URL = "http://127.0.0.1:1234/v1"; // LM Studio address
const MODEL = "google/gemma-3-4b";                 // Your loaded model
const PORT = 3000;                                  // This server's port
```
