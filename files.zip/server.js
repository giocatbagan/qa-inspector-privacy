import express from "express";
import cors from "cors";
import { v4 as uuidv4 } from "uuid";

const app = express();
app.use(cors());
app.use(express.json());

// ─────────────────────────────────────────────
//  CONFIG
// ─────────────────────────────────────────────
const LM_STUDIO_URL = "http://127.0.0.1:1234/v1";
const MODEL = "google/gemma-3-4b";
const PORT = 3000;

// ─────────────────────────────────────────────
//  IN-MEMORY SESSION STORE
//  Stores conversation history per session
// ─────────────────────────────────────────────
const sessions = new Map();

function getSession(sessionId) {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, []);
  }
  return sessions.get(sessionId);
}

// ─────────────────────────────────────────────
//  HELPER: Call LM Studio
// ─────────────────────────────────────────────
async function callLMStudio(messages) {
  const response = await fetch(`${LM_STUDIO_URL}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      messages,
      temperature: 0.7,
      max_tokens: 1024,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`LM Studio error: ${err}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// ─────────────────────────────────────────────
//  ROUTES
// ─────────────────────────────────────────────

// GET /health — check if server + LM Studio are up
app.get("/health", async (req, res) => {
  try {
    const r = await fetch(`${LM_STUDIO_URL}/models`);
    const data = await r.json();
    res.json({
      status: "ok",
      lmStudio: "connected",
      loadedModels: data.data.map((m) => m.id),
    });
  } catch {
    res.status(503).json({ status: "error", lmStudio: "unreachable" });
  }
});

// POST /chat — simple one-shot chat (no history)
// Body: { message, systemPrompt? }
app.post("/chat", async (req, res) => {
  const { message, systemPrompt } = req.body;

  if (!message) {
    return res.status(400).json({ error: "message is required" });
  }

  const messages = [];

  if (systemPrompt) {
    messages.push({ role: "system", content: systemPrompt });
  }

  messages.push({ role: "user", content: message });

  try {
    const reply = await callLMStudio(messages);
    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /session/start — create a new session with optional system prompt
// Body: { systemPrompt? }
// Returns: { sessionId }
app.post("/session/start", (req, res) => {
  const { systemPrompt } = req.body;
  const sessionId = uuidv4();
  const history = getSession(sessionId);

  if (systemPrompt) {
    history.push({ role: "system", content: systemPrompt });
  } else {
    history.push({
      role: "system",
      content: "You are a helpful, friendly assistant.",
    });
  }

  res.json({ sessionId, message: "Session started." });
});

// POST /session/:sessionId/message — send a message in an existing session
// Body: { message }
// Returns: { reply, history }
app.post("/session/:sessionId/message", async (req, res) => {
  const { sessionId } = req.params;
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: "message is required" });
  }

  if (!sessions.has(sessionId)) {
    return res.status(404).json({ error: "Session not found. Start one at POST /session/start" });
  }

  const history = getSession(sessionId);
  history.push({ role: "user", content: message });

  try {
    const reply = await callLMStudio(history);
    history.push({ role: "assistant", content: reply });
    res.json({ reply, turns: history.filter((m) => m.role !== "system").length / 2 });
  } catch (err) {
    history.pop(); // remove failed user message
    res.status(500).json({ error: err.message });
  }
});

// GET /session/:sessionId/history — get full conversation history
app.get("/session/:sessionId/history", (req, res) => {
  const { sessionId } = req.params;

  if (!sessions.has(sessionId)) {
    return res.status(404).json({ error: "Session not found" });
  }

  const history = getSession(sessionId).filter((m) => m.role !== "system");
  res.json({ sessionId, history });
});

// DELETE /session/:sessionId — clear/delete a session
app.delete("/session/:sessionId", (req, res) => {
  const { sessionId } = req.params;
  sessions.delete(sessionId);
  res.json({ message: "Session deleted." });
});

// POST /personas — chat with a preset AI personality
// Body: { persona, message, sessionId? }
const PERSONAS = {
  assistant: "You are a helpful, friendly assistant. Be concise and clear.",
  coder: "You are an expert software engineer. Give clean, well-commented code. Explain your reasoning briefly.",
  teacher: "You are a patient teacher. Explain concepts simply, use analogies, and check for understanding.",
  writer: "You are a creative writer. Help with writing, editing, and storytelling with flair and style.",
};

app.post("/personas", async (req, res) => {
  const { persona, message, sessionId } = req.body;

  if (!persona || !message) {
    return res.status(400).json({ error: "persona and message are required", available: Object.keys(PERSONAS) });
  }

  const systemPrompt = PERSONAS[persona];
  if (!systemPrompt) {
    return res.status(400).json({ error: `Unknown persona. Choose from: ${Object.keys(PERSONAS).join(", ")}` });
  }

  // If sessionId provided, use existing session
  if (sessionId && sessions.has(sessionId)) {
    const history = getSession(sessionId);
    history.push({ role: "user", content: message });
    try {
      const reply = await callLMStudio(history);
      history.push({ role: "assistant", content: reply });
      return res.json({ reply, persona, sessionId });
    } catch (err) {
      history.pop();
      return res.status(500).json({ error: err.message });
    }
  }

  // Otherwise one-shot with persona
  const messages = [
    { role: "system", content: systemPrompt },
    { role: "user", content: message },
  ];

  try {
    const reply = await callLMStudio(messages);
    res.json({ reply, persona });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────
//  GEMINI-COMPATIBLE ENDPOINTS
//  Makes LM Studio look like Google Gemini API
//  so tools like QAInspector Pro work with it
// ─────────────────────────────────────────────

// Helper: convert Gemini format → OpenAI/LM Studio format
function geminiToMessages(body) {
  const messages = [];

  // System instruction (Gemini uses systemInstruction.parts)
  if (body.systemInstruction?.parts?.length) {
    const sysText = body.systemInstruction.parts.map((p) => p.text).join("\n");
    messages.push({ role: "system", content: sysText });
  }

  // Convert Gemini "contents" → OpenAI "messages"
  for (const turn of body.contents || []) {
    const role = turn.role === "model" ? "assistant" : "user";
    const content = turn.parts?.map((p) => p.text).join("") || "";
    messages.push({ role, content });
  }

  return messages;
}

// Helper: wrap LM Studio reply → Gemini response format
function toGeminiResponse(text) {
  return {
    candidates: [
      {
        content: {
          parts: [{ text }],
          role: "model",
        },
        finishReason: "STOP",
        index: 0,
      },
    ],
    usageMetadata: {
      promptTokenCount: 0,
      candidatesTokenCount: 0,
      totalTokenCount: 0,
    },
    modelVersion: MODEL,
  };
}

// Gemini list models endpoint
// GET /v1beta/models
app.get("/v1beta/models", (req, res) => {
  res.json({
    models: [
      {
        name: `models/${MODEL}`,
        displayName: MODEL,
        description: "Local model via LM Studio",
        supportedGenerationMethods: ["generateContent"],
      },
    ],
  });
});

// Gemini generateContent endpoint
// POST /v1beta/models/:model:generateContent
app.post("/v1beta/models/:model\\:generateContent", async (req, res) => {
  try {
    const messages = geminiToMessages(req.body);

    if (!messages.length) {
      return res.status(400).json({ error: { message: "No contents provided", code: 400 } });
    }

    const text = await callLMStudio(messages);
    res.json(toGeminiResponse(text));
  } catch (err) {
    res.status(500).json({
      error: { message: err.message, code: 500, status: "INTERNAL" },
    });
  }
});

// Also handle v1 path (some tools use /v1 instead of /v1beta)
app.post("/v1/models/:model\\:generateContent", async (req, res) => {
  try {
    const messages = geminiToMessages(req.body);
    const text = await callLMStudio(messages);
    res.json(toGeminiResponse(text));
  } catch (err) {
    res.status(500).json({
      error: { message: err.message, code: 500, status: "INTERNAL" },
    });
  }
});

// ─────────────────────────────────────────────
//  START
// ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════╗
║   🤖 LM Studio API Wrapper                       ║
║   Running at http://localhost:${PORT}              ║
╠══════════════════════════════════════════════════╣
║  GET  /health                                    ║
║  POST /chat                                      ║
║  POST /session/start                             ║
║  POST /session/:id/message                       ║
║  GET  /session/:id/history                       ║
║  DEL  /session/:id                               ║
║  POST /personas                                  ║
╠══════════════════════════════════════════════════╣
║  🔁 GEMINI-COMPATIBLE (for QAInspector etc.)     ║
║  GET  /v1beta/models                             ║
║  POST /v1beta/models/:model:generateContent      ║
║  POST /v1/models/:model:generateContent          ║
╚══════════════════════════════════════════════════╝
  `);
});
